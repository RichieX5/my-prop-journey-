import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { AppProvider, useApp } from './context/AppContext'
import BottomNav from './components/BottomNav'
import Toast     from './components/Toast'

import Login      from './pages/Login'
import Register   from './pages/Register'
import Onboarding from './pages/Onboarding'
import Dashboard  from './pages/Dashboard'
import Accounts   from './pages/Accounts'
import AddAccount from './pages/AddAccount'
import Payouts    from './pages/Payouts'
import Performance from './pages/Performance'
import Goals      from './pages/Goals'

const AUTH_PATHS = ['/login', '/register', '/welcome']

function Guard({ children, requireAuth }) {
  const { session, loading } = useApp()
  const loc = useLocation()
  if (loading) return <Loader />
  if (requireAuth && !session) return <Navigate to="/login" replace />
  if (!requireAuth && session)  return <Navigate to="/"     replace />
  return children
}

function Loader() {
  return (
    <div style={{ height:'100vh', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', background:'#F0F4FF', gap:16 }}>
      <div style={{ width:56, height:56, borderRadius:16, background:'linear-gradient(135deg,#5B4FE9,#818CF8)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:26 }}>📈</div>
      <div style={{ fontFamily:"'Syne',sans-serif", fontSize:20, fontWeight:900, color:'#0F172A' }}>My Prop Journey</div>
      <div className="spinner spinner-dark" />
    </div>
  )
}

function Layout() {
  const { session } = useApp()
  const loc = useLocation()
  const showNav = session && !AUTH_PATHS.includes(loc.pathname)
  return (
    <div className="app-shell">
      <Toast />
      <Routes>
        <Route path="/welcome"  element={<Guard requireAuth={false}><Onboarding /></Guard>} />
        <Route path="/login"    element={<Guard requireAuth={false}><Login /></Guard>} />
        <Route path="/register" element={<Guard requireAuth={false}><Register /></Guard>} />
        <Route path="/"         element={<Guard requireAuth><Dashboard /></Guard>} />
        <Route path="/accounts" element={<Guard requireAuth><Accounts /></Guard>} />
        <Route path="/add"      element={<Guard requireAuth><AddAccount /></Guard>} />
        <Route path="/payouts"  element={<Guard requireAuth><Payouts /></Guard>} />
        <Route path="/performance" element={<Guard requireAuth><Performance /></Guard>} />
        <Route path="/goals"    element={<Guard requireAuth><Goals /></Guard>} />
        <Route path="*"         element={<Navigate to="/" replace />} />
      </Routes>
      {showNav && <BottomNav />}
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <Layout />
      </AppProvider>
    </BrowserRouter>
  )
}
