import { useNavigate, useLocation } from 'react-router-dom'

const NAV = [
  { path: '/',            icon: '🏠', label: 'Home'     },
  { path: '/accounts',   icon: '📋', label: 'Accounts' },
  { path: '/add',        icon: '➕', label: 'Add'      },
  { path: '/payouts',    icon: '💰', label: 'Payouts'  },
  { path: '/goals',      icon: '🎯', label: 'Goals'    },
]

export default function BottomNav() {
  const nav = useNavigate()
  const loc = useLocation()
  return (
    <nav className="bottom-nav">
      {NAV.map(n => (
        <button key={n.path} className={`nav-btn${loc.pathname===n.path?' active':''}`} onClick={() => nav(n.path)}>
          <span className="ni">{n.icon}</span>
          <span className="nl">{n.label}</span>
        </button>
      ))}
    </nav>
  )
}
