// ── Toast ─────────────────────────────────────────
import { useApp } from '../context/AppContext'
export function Toast() {
  const { toast } = useApp()
  if (!toast) return null
  return <div className={`toast show ${toast.type}`}>{toast.type==='success'?'✓ ':toast.type==='error'?'✕ ':''}{toast.msg}</div>
}
export default Toast
