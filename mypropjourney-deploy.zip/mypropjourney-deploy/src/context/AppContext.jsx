import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { supabase, getAccounts, getGoals, getMilestones, getProfile } from '../lib/supabase'
import { DEFAULT_GOAL, GRADES, getGrade } from '../lib/constants'

const Ctx = createContext(null)
export const useApp = () => { const c = useContext(Ctx); if (!c) throw new Error('useApp outside provider'); return c }

export function AppProvider({ children }) {
  const [session,    setSession]    = useState(null)
  const [profile,    setProfile]    = useState(null)
  const [accounts,   setAccounts]   = useState([])
  const [goals,      setGoals]      = useState([])
  const [milestones, setMilestones] = useState([])
  const [loading,    setLoading]    = useState(true)
  const [toast,      setToast]      = useState(null)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      if (session) load(session.user.id)
      else setLoading(false)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setSession(session)
      if (session) load(session.user.id)
      else { setAccounts([]); setGoals([]); setMilestones([]); setProfile(null); setLoading(false) }
    })
    return () => subscription.unsubscribe()
  }, [])

  async function load(uid) {
    setLoading(true)
    try {
      const [p, a, g, m] = await Promise.all([
        getProfile(uid), getAccounts(uid), getGoals(uid), getMilestones(uid)
      ])
      if (p.data)  setProfile(p.data)
      if (a.data)  setAccounts(a.data)
      if (g.data)  setGoals(g.data)
      if (m.data)  setMilestones(m.data)
    } catch (e) { console.error(e) }
    finally { setLoading(false) }
  }

  const refresh = useCallback(() => { if (session?.user?.id) load(session.user.id) }, [session])

  const showToast = useCallback((msg, type = 'default') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 2800)
  }, [])

  // ── Computed stats ──────────────────────────
  const stats = computeStats(accounts, goals)

  return (
    <Ctx.Provider value={{
      session, profile, accounts, goals, milestones, loading, toast,
      setAccounts, setGoals, setMilestones, setProfile,
      refresh, showToast, stats,
      userId: session?.user?.id,
    }}>
      {children}
    </Ctx.Provider>
  )
}

function computeStats(accounts, goals) {
  const funded    = accounts.filter(a => a.status === 'Funded')
  const challenge = accounts.filter(a => a.status === 'Challenge')
  const breached  = accounts.filter(a => a.status === 'Breached')

  const totalFunding = funded.reduce((s, a) => s + (a.size_value || 0), 0)
  const totalInv     = accounts.reduce((s, a) => s + (a.investment || 0), 0)
  const totalPay     = accounts.reduce((s, a) =>
    s + (a.payouts || []).reduce((ps, p) => ps + (p.amount || 0), 0), 0)
  const netProfit    = totalPay - totalInv

  const mainGoal  = goals.find(g => g.is_main) || { target: DEFAULT_GOAL }
  const goalPct   = Math.min((totalPay / mainGoal.target) * 100, 100)

  const allPayouts = accounts.flatMap(a =>
    (a.payouts || []).map(p => ({ ...p, firm: a.firm, firmId: a.id }))
  ).sort((a, b) => (b.date || '').localeCompare(a.date || ''))

  const monthMap = {}
  allPayouts.forEach(p => {
    if (!p.date) return
    const m = p.date.slice(0, 7)
    monthMap[m] = (monthMap[m] || 0) + p.amount
  })
  const monthly = Object.entries(monthMap).sort().slice(-8).map(([k, v]) => ({ month: k, v }))

  // Firm leaderboard
  const firmPay = {}
  accounts.forEach(a => {
    const pay = (a.payouts || []).reduce((s, p) => s + (p.amount || 0), 0)
    firmPay[a.firm] = (firmPay[a.firm] || 0) + pay
  })
  const leaderboard = Object.entries(firmPay)
    .filter(([, v]) => v > 0)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)

  // Performance
  const perf = computePerf(accounts, totalPay, totalInv, mainGoal.target)

  return {
    funded, challenge, breached,
    totalFunding, totalInv, totalPay, netProfit,
    goalPct, mainGoal, allPayouts, monthly, leaderboard, perf,
    breachRate: accounts.length ? Math.round((breached.length / accounts.length) * 100) : 0,
    fundingRate: accounts.length ? Math.round((funded.length / accounts.length) * 100) : 0,
    roi: totalInv > 0 ? Math.round(((totalPay - totalInv) / totalInv) * 100) : 0,
  }
}

function computePerf(accounts, totalPay, totalInv, goalTarget) {
  if (!accounts.length) return null
  const total      = accounts.length
  const fundedCnt  = accounts.filter(a => a.status === 'Funded').length
  const breachedCnt= accounts.filter(a => a.status === 'Breached').length
  const winRate    = fundedCnt / total
  const roi        = totalInv > 0 ? (totalPay - totalInv) / totalInv : 0
  const breachRate = breachedCnt / total
  const divScore   = Math.min(new Set(accounts.map(a => a.firm)).size * 20, 100)

  const winScore    = Math.round(winRate * 100)
  const roiScore    = Math.min(Math.round(Math.max(roi, 0) * 150), 100)
  const breachScore = Math.round(Math.max(0, 1 - breachRate) * 100)
  const payScore    = Math.min(Math.round((totalPay / (goalTarget || DEFAULT_GOAL)) * 100), 100)
  const overall     = Math.round((winScore + roiScore + breachScore + divScore + payScore) / 5)

  return { winScore, roiScore, breachScore, divScore, payScore, overall, ...getGrade(overall), winRate, roi, breachRate }
}
