export { Goals as default } from './Payouts'
