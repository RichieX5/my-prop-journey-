import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { STATUS_META, FIRMS } from '../lib/constants'
import AddAccount from './AddAccount'

function fmt(v) {
  if (!v && v !== 0) return '$0'
  const n = Number(v)
  if (n >= 1e6) return `$${(n/1e6).toFixed(2)}M`
  if (n >= 1e3) return `$${(n/1e3).toFixed(1)}K`
  return `$${n.toLocaleString()}`
}

function GoalRing({ pct }) {
  const r = 32, circ = 2 * Math.PI * r
  const used = (Math.min(pct,100) / 100) * circ
  return (
    <svg width="76" height="76" style={{ transform:'rotate(-90deg)', flexShrink:0 }}>
      <circle cx="38" cy="38" r={r} fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="8"/>
      <circle cx="38" cy="38" r={r} fill="none" stroke="url(#rg)" strokeWidth="8"
        strokeDasharray={`${used} ${circ}`} strokeLinecap="round"/>
      <defs>
        <linearGradient id="rg" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#A5F3D4"/>
          <stop offset="100%" stopColor="#6EE7B7"/>
        </linearGradient>
      </defs>
    </svg>
  )
}

function MiniChart({ data }) {
  if (!data.length) return <div style={{ height:44, display:'flex', alignItems:'center', justifyContent:'center' }}><span style={{ fontSize:11, color:'#94A3B8' }}>Log payouts with dates to see chart</span></div>
  const max = Math.max(...data.map(d => d.v), 1)
  return (
    <div>
      <div style={{ display:'flex', alignItems:'flex-end', gap:4, height:44 }}>
        {data.map((d,i) => (
          <div key={i} style={{ flex:1, borderRadius:'3px 3px 0 0', minHeight:4, background: i===data.length-1?'#059669':'#5B4FE9', opacity:0.4+(i/data.length)*0.6, height:`${Math.max(6,(d.v/max)*100)}%` }}/>
        ))}
      </div>
      <div style={{ display:'flex', gap:4, marginTop:3 }}>
        {data.map((d,i) => <div key={i} style={{ flex:1, fontSize:7, color:'#94A3B8', textAlign:'center' }}>{d.month.slice(5)}</div>)}
      </div>
    </div>
  )
}

export default function Dashboard() {
  const { stats, accounts, profile } = useApp()
  const nav = useNavigate()
  const { funded, challenge, breached, totalFunding, totalPay, netProfit, goalPct, mainGoal, monthly, leaderboard, perf } = stats
  const RANK_COLORS = ['#D97706','#94A3B8','#CD7F32']

  return (
    <div className="page">
      {/* Top bar */}
      <div style={{ padding:'calc(env(safe-area-inset-top,0px) + 13px) 16px 0', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <div style={{ fontSize:10, color:'#94A3B8', fontWeight:600 }}>Good day 👋</div>
          <div style={{ fontFamily:"'Syne',sans-serif", fontSize:19, fontWeight:900, color:'#0F172A' }}>
            {profile?.full_name?.split(' ')[0] || 'My Prop Journey'}
          </div>
        </div>
        <div style={{ width:38, height:38, borderRadius:'50%', background:'linear-gradient(135deg,#5B4FE9,#818CF8)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:17, boxShadow:'0 4px 12px rgba(91,79,233,0.3)' }}>🧑‍💼</div>
      </div>

      {/* GOAL HERO CARD */}
      <div style={{ margin:'13px 16px 0', background:'linear-gradient(145deg,#5B4FE9 0%,#4338CA 60%,#3730A3 100%)', borderRadius:24, padding:'18px 18px 16px', boxShadow:'0 8px 28px rgba(91,79,233,0.35)', position:'relative', overflow:'hidden' }}>
        <div style={{ position:'absolute', top:-30, right:-30, width:100, height:100, background:'rgba(255,255,255,0.07)', borderRadius:'50%' }}/>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:14 }}>
          <div>
            <div style={{ fontSize:9, fontWeight:700, color:'rgba(255,255,255,0.6)', letterSpacing:1.5, textTransform:'uppercase', marginBottom:5 }}>Combined Payouts · All Firms</div>
            <div style={{ fontFamily:"'Syne',sans-serif", fontSize:30, fontWeight:900, color:'#fff', lineHeight:1 }}>{fmt(totalPay)}</div>
            <div style={{ fontSize:11, fontWeight:700, color:'#A5F3D4', marginTop:5 }}>
              {goalPct >= 100 ? '🎉 Goal reached!' : `▲ ${fmt(Math.max((mainGoal?.target||150000)-totalPay,0))} to reach ${fmt(mainGoal?.target||150000)}`}
            </div>
          </div>
          <div style={{ position:'relative' }}>
            <GoalRing pct={goalPct}/>
            <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center' }}>
              <span style={{ fontSize:13, fontWeight:900, color:'#fff' }}>{Math.round(goalPct)}%</span>
              <span style={{ fontSize:7, color:'rgba(255,255,255,0.6)', fontWeight:600 }}>goal</span>
            </div>
          </div>
        </div>
        {/* Firm breakdown bar */}
        {leaderboard.length > 0 && (
          <>
            <div style={{ display:'flex', gap:3, height:8, borderRadius:4, overflow:'hidden', marginBottom:6 }}>
              {leaderboard.map(([, v],i) => {
                const colors=['rgba(255,255,255,0.9)','rgba(255,255,255,0.65)','rgba(255,255,255,0.42)','rgba(255,255,255,0.25)','rgba(255,255,255,0.15)']
                return <div key={i} style={{ flex:v, background:colors[i]||colors[4], borderRadius:2 }}/>
              })}
              <div style={{ flex: Math.max((mainGoal?.target||150000)-totalPay,0), background:'rgba(255,255,255,0.1)', borderRadius:2 }}/>
            </div>
            <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
              {leaderboard.slice(0,3).map(([name,v],i) => {
                const colors=['rgba(255,255,255,0.9)','rgba(255,255,255,0.65)','rgba(255,255,255,0.42)']
                return <div key={i} style={{ display:'flex', alignItems:'center', gap:4 }}>
                  <div style={{ width:7, height:7, borderRadius:'50%', background:colors[i], flexShrink:0 }}/>
                  <span style={{ fontSize:9, color:'rgba(255,255,255,0.7)', fontWeight:600 }}>{name.split(' ')[0]} {fmt(v)}</span>
                </div>
              })}
            </div>
          </>
        )}
      </div>

      {/* STATUS PILLS */}
      <div style={{ display:'flex', gap:9, padding:'13px 16px 0', overflowX:'auto', scrollbarWidth:'none' }}>
        {[
          { n: funded.length,    label:'Funded',    bg:'#ECFDF5', bc:'#6EE7B7', c:'#059669' },
          { n: challenge.length, label:'Challenge', bg:'#EEF0FF', bc:'#C4BFFF', c:'#5B4FE9' },
          { n: breached.length,  label:'Breached',  bg:'#FEF2F2', bc:'#FCA5A5', c:'#DC2626' },
          { n: accounts.length,  label:'Total',     bg:'#fff',    bc:'#C8D4F0', c:'#475569' },
        ].map(s => (
          <div key={s.label} style={{ flexShrink:0, background:s.bg, border:`1.5px solid ${s.bc}`, borderRadius:14, padding:'10px 14px', display:'flex', flexDirection:'column', alignItems:'center', gap:3, boxShadow:'0 2px 8px rgba(0,0,0,0.05)' }}>
            <span style={{ fontSize:22, fontWeight:900, lineHeight:1, color:s.c }}>{s.n}</span>
            <span style={{ fontSize:8, fontWeight:700, color:'#94A3B8', letterSpacing:0.5 }}>{s.label}</span>
          </div>
        ))}
      </div>

      {/* ACCOUNT STRIP — HERO FEATURE */}
      <div className="sec-hdr" style={{ paddingTop:14 }}>
        <span className="sh-t">📊 All Accounts <span style={{ color:'#94A3B8', fontWeight:600 }}>({accounts.length})</span></span>
        <button className="sh-l" onClick={() => nav('/accounts')}>View all →</button>
      </div>

      {accounts.length === 0 ? (
        <div style={{ margin:'0 16px', background:'#fff', border:'2px dashed #C4BFFF', borderRadius:18, padding:'28px 20px', textAlign:'center' }}>
          <div style={{ fontSize:36, marginBottom:10 }}>🏢</div>
          <div style={{ fontFamily:"'Syne',sans-serif", fontSize:15, fontWeight:800, color:'#0F172A', marginBottom:6 }}>No accounts yet</div>
          <p style={{ fontSize:12, color:'#94A3B8', marginBottom:14 }}>Tap below to log your first prop firm account</p>
          <button className="btn btn-primary" style={{ width:'auto', padding:'11px 24px' }} onClick={() => nav('/add')}>+ Add First Account</button>
        </div>
      ) : (
        <div className="hscroll" style={{ paddingBottom:6 }}>
          {accounts.map(acc => {
            const m = STATUS_META[acc.status] || STATUS_META.Challenge
            const pay = (acc.payouts||[]).reduce((s,p) => s+(p.amount||0), 0)
            return (
              <div key={acc.id} onClick={() => nav('/accounts')} style={{ minWidth:148, flexShrink:0, borderRadius:18, padding:14, border:`2px solid ${m.border}`, cursor:'pointer', background:'#fff', boxShadow:'0 3px 12px rgba(0,0,0,0.07)', background: acc.status==='Funded'?'linear-gradient(160deg,#fff,#F0FDF9)': acc.status==='Breached'?'linear-gradient(160deg,#fff,#FFF5F5)':'linear-gradient(160deg,#fff,#F5F3FF)' }}>
                <div style={{ width:34, height:34, borderRadius:10, background:m.bg, display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, fontWeight:900, marginBottom:9, fontFamily:"'Syne',sans-serif", color:m.color }}>{acc.firm.charAt(0)}</div>
                <div style={{ fontSize:12, fontWeight:800, color:'#0F172A', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis', marginBottom:1 }}>{acc.firm}</div>
                <div style={{ fontSize:9, color:'#94A3B8', fontWeight:600, marginBottom:8 }}>{acc.size_label||'Account'}</div>
                <div style={{ fontSize:16, fontWeight:900, color: pay>0?'#059669':acc.status==='Breached'?'#DC2626':'#5B4FE9', marginBottom:5 }}>{pay>0?fmt(pay): acc.status==='Challenge'?'In Progress':'—'}</div>
                <span className={`badge badge-${acc.status.toLowerCase()}`}>{m.emoji} {acc.status}</span>
              </div>
            )
          })}
        </div>
      )}

      {/* AGG STATS */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, padding:'13px 16px 0' }}>
        {[
          { label:'Active Funding', v:fmt(totalFunding), sub:`${funded.length} funded`, color:'#5B4FE9' },
          { label:'Net Profit',     v:`${netProfit>=0?'+':'−'}${fmt(Math.abs(netProfit))}`, sub:netProfit>=0?'Profitable':'In loss', color:netProfit>=0?'#059669':'#DC2626' },
          { label:'Fees Invested',  v:fmt(stats.totalInv), sub:`${accounts.length} accounts`, color:'#0284C7' },
          { label:'Breach Rate',    v:`${stats.breachRate}%`, sub:`${breached.length} breached`, color:breached.length?'#DC2626':'#059669' },
        ].map(s => (
          <div key={s.label} style={{ background:'#fff', border:`1.5px solid #E2E8F8`, borderTop:`4px solid ${s.color}`, borderRadius:16, padding:13, boxShadow:'0 2px 8px rgba(0,0,0,0.05)' }}>
            <div style={{ fontSize:8, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:1, marginBottom:5 }}>{s.label}</div>
            <div style={{ fontSize:21, fontWeight:900, lineHeight:1, color:s.color, marginBottom:2 }}>{s.v}</div>
            <div style={{ fontSize:10, fontWeight:700, color:s.color }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* FIRM LEADERBOARD */}
      {leaderboard.length > 0 && (
        <>
          <div className="sec-hdr" style={{ paddingTop:14 }}><span className="sh-t">🏆 Firm Leaderboard</span></div>
          <div style={{ margin:'0 16px', background:'#fff', border:'1.5px solid #E2E8F8', borderRadius:18, padding:16, boxShadow:'0 2px 8px rgba(0,0,0,0.05)' }}>
            {leaderboard.map(([name, v], i) => {
              const colors = ['#5B4FE9','#059669','#D97706','#0284C7','#DC2626']
              const maxV = leaderboard[0][1]
              return (
                <div key={name} style={{ display:'flex', alignItems:'center', gap:9, marginBottom: i<leaderboard.length-1?10:0 }}>
                  <span style={{ width:20, fontSize:14, textAlign:'center', flexShrink:0 }}>{['🥇','🥈','🥉','4️⃣','5️⃣'][i]}</span>
                  <div style={{ width:9, height:9, borderRadius:'50%', background:colors[i], flexShrink:0 }}/>
                  <span style={{ fontSize:12, fontWeight:700, color:'#0F172A', flex:1 }}>{name}</span>
                  <div style={{ width:64, height:7, background:'#E2E8F8', borderRadius:4, overflow:'hidden', flexShrink:0 }}>
                    <div style={{ height:'100%', width:`${(v/maxV)*100}%`, background:colors[i], borderRadius:4 }}/>
                  </div>
                  <span style={{ fontSize:12, fontWeight:800, color:colors[i], width:44, textAlign:'right', flexShrink:0 }}>{fmt(v)}</span>
                </div>
              )
            })}
          </div>
        </>
      )}

      {/* MONTHLY CHART */}
      <div className="sec-hdr" style={{ paddingTop:14 }}><span className="sh-t">📅 Monthly Payouts</span></div>
      <div style={{ margin:'0 16px 16px', background:'#fff', border:'1.5px solid #E2E8F8', borderRadius:18, padding:14, boxShadow:'0 2px 8px rgba(0,0,0,0.05)' }}>
        <MiniChart data={monthly}/>
      </div>

      <button className="fab" onClick={() => nav('/add')}>+</button>
    </div>
  )
}
