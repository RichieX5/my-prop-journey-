import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { signIn, signUp } from '../lib/supabase'
import { useApp } from '../context/AppContext'

function AuthWrap({ children }) {
  return (
    <div style={{ height:'100vh', overflow:'auto', background:'#F0F4FF', padding:'0 24px' }}>
      <div style={{ textAlign:'center', padding:'52px 0 28px' }}>
        <div style={{ width:52, height:52, borderRadius:16, background:'linear-gradient(135deg,#5B4FE9,#818CF8)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:24, margin:'0 auto 16px', boxShadow:'0 4px 14px rgba(91,79,233,0.3)' }}>📈</div>
        <div style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:900, color:'#0F172A', marginBottom:4 }}>My Prop Journey</div>
      </div>
      {children}
    </div>
  )
}

export function Login() {
  const [email, setEmail]       = useState('')
  const [pass,  setPass]        = useState('')
  const [err,   setErr]         = useState('')
  const [load,  setLoad]        = useState(false)
  const { showToast }           = useApp()
  const nav                     = useNavigate()

  async function submit(e) {
    e.preventDefault()
    if (!email || !pass) return setErr('Please fill in all fields')
    setLoad(true); setErr('')
    const { error } = await signIn(email, pass)
    setLoad(false)
    if (error) setErr(error.message)
    else { showToast('Welcome back! 👋', 'success'); nav('/') }
  }

  return (
    <AuthWrap>
      <h2 style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:900, color:'#0F172A', marginBottom:6 }}>Welcome back</h2>
      <p style={{ fontSize:13, color:'#94A3B8', marginBottom:22 }}>Log in to your account</p>
      <form onSubmit={submit}>
        <div className="form-group">
          <label className="form-label">Email</label>
          <input className="form-input" type="email" placeholder="you@email.com" value={email} onChange={e=>{setEmail(e.target.value);setErr('')}} autoComplete="email"/>
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input className="form-input" type="password" placeholder="••••••••" value={pass} onChange={e=>{setPass(e.target.value);setErr('')}} autoComplete="current-password"/>
        </div>
        {err && <div className="form-error" style={{ marginBottom:12, textAlign:'center' }}>⚠ {err}</div>}
        <button className="btn btn-primary" type="submit" disabled={load} style={{ marginTop:4 }}>
          {load ? <div className="spinner"/> : 'Log In'}
        </button>
      </form>
      <p style={{ textAlign:'center', marginTop:18, fontSize:13, color:'#94A3B8', paddingBottom:32 }}>
        No account? <Link to="/register" style={{ color:'#5B4FE9', fontWeight:700 }}>Sign up free</Link>
      </p>
    </AuthWrap>
  )
}

export function Register() {
  const [name, setName]   = useState('')
  const [email, setEmail] = useState('')
  const [pass,  setPass]  = useState('')
  const [err,   setErr]   = useState('')
  const [load,  setLoad]  = useState(false)
  const { showToast }     = useApp()
  const nav               = useNavigate()

  async function submit(e) {
    e.preventDefault()
    if (!name || !email || !pass) return setErr('Please fill in all fields')
    if (pass.length < 6) return setErr('Password must be at least 6 characters')
    setLoad(true); setErr('')
    const { error } = await signUp(email, pass, name)
    setLoad(false)
    if (error) setErr(error.message)
    else { showToast('Account created! Check your email ✓', 'success'); nav('/login') }
  }

  return (
    <AuthWrap>
      <h2 style={{ fontFamily:"'Syne',sans-serif", fontSize:22, fontWeight:900, color:'#0F172A', marginBottom:6 }}>Start your journey</h2>
      <p style={{ fontSize:13, color:'#94A3B8', marginBottom:22 }}>Free account — no credit card needed</p>
      <form onSubmit={submit}>
        <div className="form-group">
          <label className="form-label">Full Name</label>
          <input className="form-input" type="text" placeholder="Your name" value={name} onChange={e=>{setName(e.target.value);setErr('')}} autoComplete="name"/>
        </div>
        <div className="form-group">
          <label className="form-label">Email</label>
          <input className="form-input" type="email" placeholder="you@email.com" value={email} onChange={e=>{setEmail(e.target.value);setErr('')}} autoComplete="email"/>
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input className="form-input" type="password" placeholder="Min. 6 characters" value={pass} onChange={e=>{setPass(e.target.value);setErr('')}} autoComplete="new-password"/>
        </div>
        {err && <div className="form-error" style={{ marginBottom:12, textAlign:'center' }}>⚠ {err}</div>}
        <div style={{ background:'#EEF0FF', border:'1.5px solid #C4BFFF', borderRadius:10, padding:12, marginBottom:14, fontSize:11, color:'#5B4FE9', lineHeight:1.6 }}>
          ✓ Free forever · Track unlimited accounts · No credit card needed
        </div>
        <button className="btn btn-primary" type="submit" disabled={load}>
          {load ? <div className="spinner"/> : 'Create Free Account'}
        </button>
      </form>
      <p style={{ textAlign:'center', marginTop:16, fontSize:13, color:'#94A3B8', paddingBottom:32 }}>
        Have an account? <Link to="/login" style={{ color:'#5B4FE9', fontWeight:700 }}>Log in</Link>
      </p>
    </AuthWrap>
  )
}

export default Login
