// ══ ACCOUNTS PAGE ══════════════════════════════════════════════
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { deleteAccount, addPayout, deletePayout, updateAccount } from '../lib/supabase'
import { STATUS_META, STATUSES } from '../lib/constants'

const fmt = v => { if(!v&&v!==0)return'$0'; const n=Number(v); if(n>=1e6)return`$${(n/1e6).toFixed(2)}M`; if(n>=1e3)return`$${(n/1e3).toFixed(1)}K`; return`$${n.toLocaleString()}` }
const fmtFull = v => `$${Number(v||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}`

function PayoutModal({ account, onClose }) {
  const { userId, showToast, refresh } = useApp()
  const [amount, setAmount] = useState('')
  const [date,   setDate]   = useState(new Date().toISOString().slice(0,10))
  const [note,   setNote]   = useState('')
  const [saving, setSaving] = useState(false)

  async function save() {
    if (!amount || parseFloat(amount) <= 0) return showToast('Enter a valid amount', 'error')
    setSaving(true)
    const { error } = await addPayout({ account_id: account.id, user_id: userId, amount: parseFloat(amount), date, note: note.trim() })
    setSaving(false)
    if (error) showToast(error.message, 'error')
    else { showToast('Payout added ✓', 'success'); refresh(); onClose() }
  }

  return (
    <div className="modal-overlay" onClick={e => e.target===e.currentTarget && onClose()}>
      <div className="modal-box">
        <div className="modal-handle"/>
        <div className="modal-hdr">
          <span className="modal-title">Add Payout — {account.firm}</span>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <div className="form-group">
            <label className="form-label">Payout Amount ($)</label>
            <input className="form-input" type="number" placeholder="e.g. 5000" value={amount} onChange={e=>setAmount(e.target.value)} autoFocus/>
          </div>
          <div className="form-row">
            <div className="form-group" style={{marginBottom:0}}>
              <label className="form-label">Date</label>
              <input className="form-input" type="date" value={date} onChange={e=>setDate(e.target.value)}/>
            </div>
            <div className="form-group" style={{marginBottom:0}}>
              <label className="form-label">Note (optional)</label>
              <input className="form-input" type="text" placeholder="e.g. Phase 1" value={note} onChange={e=>setNote(e.target.value)}/>
            </div>
          </div>
          <div style={{ display:'flex', gap:10, marginTop:18 }}>
            <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
            <button className="btn btn-green" onClick={save} disabled={saving}>{saving?<div className="spinner"/>:'Save Payout'}</button>
          </div>
        </div>
      </div>
    </div>
  )
}

function AccountCard({ account }) {
  const { showToast, refresh } = useApp()
  const [open,    setOpen]    = useState(false)
  const [payModal,setPayModal]= useState(false)
  const m   = STATUS_META[account.status] || STATUS_META.Challenge
  const pay = (account.payouts||[]).reduce((s,p)=>s+(p.amount||0),0)
  const inv = account.investment || 0

  async function handleDelete() {
    if (!confirm(`Delete ${account.firm} account? This cannot be undone.`)) return
    const { error } = await deleteAccount(account.id)
    if (error) showToast(error.message,'error')
    else { showToast('Account deleted','success'); refresh() }
  }

  async function handleDeletePayout(id) {
    const { error } = await deletePayout(id)
    if (error) showToast(error.message,'error')
    else { showToast('Payout removed','success'); refresh() }
  }

  return (
    <>
      <div style={{ margin:'0 16px 10px', background:'#fff', border:`2px solid ${m.border}`, borderTop:`4px solid ${m.color}`, borderRadius:20, overflow:'hidden', boxShadow:'0 3px 12px rgba(0,0,0,0.07)' }}>
        {/* Top */}
        <div onClick={()=>setOpen(o=>!o)} style={{ padding:'13px 14px', display:'flex', alignItems:'center', gap:11, cursor:'pointer' }}>
          <div style={{ width:44, height:44, borderRadius:13, background:m.bg, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, fontWeight:900, flexShrink:0, fontFamily:"'Syne',sans-serif", color:m.color }}>{account.firm.charAt(0)}</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:14, fontWeight:800, color:'#0F172A', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{account.firm}</div>
            <div style={{ fontSize:11, color:'#475569', marginTop:2 }}>{account.size_label} · {(account.payouts||[]).length} payout{(account.payouts||[]).length!==1?'s':''}</div>
          </div>
          <div style={{ textAlign:'right', flexShrink:0 }}>
            <div style={{ fontSize:16, fontWeight:900, color: pay>0?'#059669':account.status==='Breached'?'#DC2626':'#94A3B8' }}>{pay>0?fmt(pay):'—'}</div>
            <span className={`badge badge-${account.status.toLowerCase()}`} style={{ marginTop:3, display:'inline-block' }}>{m.emoji} {account.status}</span>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', borderTop:'1.5px solid #E2E8F8' }}>
          {[
            { l:'Invested', v:`$${inv.toLocaleString()}`, c:'#475569' },
            { l:'Net P&L',  v:`${pay-inv>=0?'+':'−'}${fmt(Math.abs(pay-inv))}`, c:pay-inv>=0?'#059669':'#DC2626' },
            { l:'ROI',      v: inv>0?`${Math.round(((pay-inv)/inv)*100)}%`:'—', c:pay-inv>=0?'#059669':'#DC2626' },
          ].map(s=>(
            <div key={s.l} style={{ padding:'9px 10px', textAlign:'center', borderRight:'1.5px solid #E2E8F8' }}>
              <div style={{ fontSize:7, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:0.5, marginBottom:3 }}>{s.l}</div>
              <div style={{ fontSize:13, fontWeight:900, color:s.c }}>{s.v}</div>
            </div>
          ))}
        </div>

        {/* Rules */}
        {open && (account.rules||[]).length > 0 && (
          <div style={{ borderTop:'1.5px solid #E2E8F8', padding:'12px 14px' }}>
            <div style={{ fontSize:9, fontWeight:700, color:'#94A3B8', letterSpacing:1.5, textTransform:'uppercase', marginBottom:9 }}>Account Rules</div>
            {(account.rules||[]).map(r => (
              <div key={r.id} className="rule-row">
                <span className="ri">📋</span>
                <div className="rb"><div className="rn">{r.rule_name}</div><div className="rv">{r.rule_value}</div></div>
              </div>
            ))}
          </div>
        )}

        {/* Payouts */}
        {open && (
          <div style={{ borderTop:'1.5px solid #E2E8F8', padding:'12px 14px' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:9 }}>
              <div style={{ fontSize:9, fontWeight:700, color:'#94A3B8', letterSpacing:1.5, textTransform:'uppercase' }}>Payouts ({(account.payouts||[]).length})</div>
              <button onClick={()=>setPayModal(true)} style={{ background:'#ECFDF5', border:'1.5px solid #6EE7B7', borderRadius:8, color:'#059669', fontSize:10, fontWeight:700, padding:'4px 10px', cursor:'pointer' }}>+ Add</button>
            </div>
            {(account.payouts||[]).length===0
              ? <div style={{ fontSize:12, color:'#94A3B8', textAlign:'center', padding:'10px 0' }}>No payouts yet</div>
              : (account.payouts||[]).map(p=>(
                <div key={p.id} style={{ display:'flex', alignItems:'center', gap:10, background:'#F7F9FF', border:'1.5px solid #E2E8F8', borderLeft:`3px solid #059669`, borderRadius:10, padding:'9px 11px', marginBottom:6 }}>
                  <div style={{ flex:1 }}>
                    <div style={{ fontSize:14, fontWeight:900, color:'#059669' }}>+${Number(p.amount).toLocaleString()}</div>
                    <div style={{ fontSize:10, color:'#94A3B8', marginTop:1 }}>{p.date||'No date'}{p.note?` · ${p.note}`:''}</div>
                  </div>
                  <button onClick={()=>handleDeletePayout(p.id)} style={{ background:'none', border:'none', color:'#FCA5A5', fontSize:16, cursor:'pointer', padding:4 }}>✕</button>
                </div>
              ))
            }
          </div>
        )}

        {/* Actions */}
        <div style={{ display:'flex', gap:8, padding:'10px 14px', borderTop:'1.5px solid #E2E8F8', background:'#F7F9FF' }}>
          <button onClick={()=>setPayModal(true)} style={{ flex:1, background:'#ECFDF5', border:'1.5px solid #6EE7B7', borderRadius:9, color:'#059669', fontFamily:'var(--font)', fontSize:11, fontWeight:700, padding:'9px', cursor:'pointer' }}>💰 Add Payout</button>
          <button onClick={handleDelete} style={{ flex:1, background:'#FEF2F2', border:'1.5px solid #FCA5A5', borderRadius:9, color:'#DC2626', fontFamily:'var(--font)', fontSize:11, fontWeight:700, padding:'9px', cursor:'pointer' }}>🗑 Delete</button>
        </div>
      </div>
      {payModal && <PayoutModal account={account} onClose={()=>setPayModal(false)}/>}
    </>
  )
}

export function Accounts() {
  const { accounts } = useApp()
  const nav = useNavigate()
  const [filter, setFilter] = useState('All')
  const list = filter==='All' ? accounts : accounts.filter(a=>a.status===filter)

  return (
    <div className="page">
      <div className="page-hdr">
        <div><h1>Accounts</h1><div className="sub">{accounts.length} total · {new Set(accounts.map(a=>a.firm)).size} firms</div></div>
        <button className="add-btn" onClick={()=>nav('/add')}>+ Add</button>
      </div>
      <div className="filter-row">
        {['All','Funded','Challenge','Breached'].map(f=>(
          <button key={f} className={`filter-pill${filter===f?' active':''}`} onClick={()=>setFilter(f)}>
            {f==='All'?`All (${accounts.length})`:f==='Funded'?`✅ Funded (${accounts.filter(a=>a.status===f).length})`:f==='Challenge'?`⏳ Challenge (${accounts.filter(a=>a.status===f).length})`:`❌ Breached (${accounts.filter(a=>a.status===f).length})`}
          </button>
        ))}
      </div>
      {list.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">📋</div>
          <h3>{accounts.length===0?'No accounts yet':'No accounts match'}</h3>
          <p>{accounts.length===0?'Add your first prop firm account to start tracking':'Try a different filter'}</p>
          {accounts.length===0&&<button className="btn btn-primary" style={{width:'auto',padding:'12px 28px'}} onClick={()=>nav('/add')}>+ Add Account</button>}
        </div>
      ) : (
        <>
          {['Funded','Challenge','Breached'].map(status => {
            const group = list.filter(a=>a.status===status)
            if (!group.length) return null
            const m = STATUS_META[status]
            return (
              <div key={status}>
                <div className="group-lbl" style={{color:m.color}}>{m.emoji} {status.toUpperCase()} · {group.length} ACCOUNT{group.length!==1?'S':''}</div>
                {group.map(a=><AccountCard key={a.id} account={a}/>)}
              </div>
            )
          })}
        </>
      )}
      <button className="fab" onClick={()=>nav('/add')}>+</button>
    </div>
  )
}
export default Accounts
