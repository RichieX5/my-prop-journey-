import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useApp } from '../context/AppContext'
import { createAccount, createRule } from '../lib/supabase'
import { FIRM_NAMES, FIRMS, STATUSES, SIZES, RULE_TEMPLATES, STATUS_META } from '../lib/constants'

const fmt = v => !v ? '$0' : v >= 1e3 ? `$${(v/1e3).toFixed(0)}K` : `$${v}`

export default function AddAccount() {
  const { userId, showToast, refresh } = useApp()
  const nav = useNavigate()
  const [step, setStep] = useState(1)

  // Step 1 fields
  const [firm,       setFirm]       = useState(FIRM_NAMES[0])
  const [customFirm, setCustomFirm] = useState('')
  const [sizeVal,    setSizeVal]    = useState(10000)
  const [sizeLabel,  setSizeLabel]  = useState('$10K')
  const [isCustomSz, setIsCustomSz] = useState(false)
  const [customSz,   setCustomSz]   = useState('')
  const [status,     setStatus]     = useState('Challenge')
  const [investment, setInvestment] = useState('')
  const [notes,      setNotes]      = useState('')

  // Step 2 — rules
  const [rules, setRules] = useState(
    RULE_TEMPLATES.map(t => ({ ...t, value: '', enabled: true }))
  )
  const [customRules, setCustomRules] = useState([])

  const [saving, setSaving] = useState(false)

  const firmName = firm === 'Other (Custom)' ? customFirm.trim() : firm
  const affiliateUrl = FIRMS.find(f => f.name === firm)?.url || null

  function handleSizeClick(s) {
    if (s.value === 'custom') { setIsCustomSz(true); setSizeVal(0); setSizeLabel('Custom') }
    else { setIsCustomSz(false); setSizeVal(s.value); setSizeLabel(s.label) }
  }

  function updateRule(i, val) { setRules(r => r.map((x,j) => j===i ? {...x, value:val} : x)) }
  function toggleRule(i) { setRules(r => r.map((x,j) => j===i ? {...x, enabled:!x.enabled} : x)) }
  function addCustomRule() { setCustomRules(r => [...r, { name:'', value:'' }]) }
  function updateCustom(i, field, val) { setCustomRules(r => r.map((x,j) => j===i ? {...x,[field]:val} : x)) }
  function removeCustom(i) { setCustomRules(r => r.filter((_,j) => j!==i)) }

  function validateStep1() {
    if (!firmName) return 'Please select or enter a firm name'
    if (isCustomSz && (!customSz || parseFloat(customSz) <= 0)) return 'Please enter a valid account size'
    return null
  }

  async function handleSave() {
    setSaving(true)
    try {
      const finalSize = isCustomSz ? parseFloat(customSz)||0 : sizeVal
      const finalLabel = isCustomSz ? `$${Number(finalSize).toLocaleString()}` : sizeLabel

      const { data: acc, error } = await createAccount({
        user_id: userId, firm: firmName,
        size_value: finalSize, size_label: finalLabel,
        status, investment: parseFloat(investment)||0, notes: notes.trim(),
      })
      if (error) throw error

      // Save rules
      const allRules = [
        ...rules.filter(r => r.enabled && r.value.trim()),
        ...customRules.filter(r => r.name.trim() && r.value.trim()),
      ]
      for (const r of allRules) {
        await createRule({ account_id: acc.id, user_id: userId, rule_name: r.name || r.icon+' '+r.name, rule_value: r.value.trim(), status: 'ok' })
      }

      showToast('Account added ✓', 'success')
      refresh()
      nav('/accounts')
    } catch (e) {
      showToast(e.message || 'Something went wrong', 'error')
    } finally {
      setSaving(false)
    }
  }

  const m = STATUS_META[status] || STATUS_META.Challenge

  return (
    <div style={{ minHeight:'100vh', background:'#F0F4FF', paddingBottom:32 }}>
      {/* Header */}
      <div style={{ background:'#fff', padding:'calc(env(safe-area-inset-top,0px) + 13px) 16px 13px', borderBottom:'1.5px solid #E2E8F8', boxShadow:'0 2px 8px rgba(91,79,233,0.07)', position:'sticky', top:0, zIndex:40 }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
          <div>
            <div style={{ fontFamily:"'Syne',sans-serif", fontSize:18, fontWeight:900, color:'#0F172A' }}>
              {step===1?'Account Details':step===2?'Log Account Rules':'Review & Save'}
            </div>
            <div style={{ fontSize:10, color:'#94A3B8', marginTop:1 }}>Step {step} of 3</div>
          </div>
          <button onClick={() => nav(-1)} style={{ background:'#F0F4FF', border:'1.5px solid #C8D4F0', borderRadius:10, color:'#94A3B8', fontSize:13, fontWeight:700, padding:'7px 12px', cursor:'pointer' }}>✕</button>
        </div>
        <div className="step-dots">
          {[1,2,3].map(n => <div key={n} className={`step-dot ${n<step?'done':n===step?'active':''}`}/>)}
        </div>
      </div>

      <div style={{ padding:'16px 16px 0' }}>

        {/* ── STEP 1 ── */}
        {step === 1 && (
          <div className="fade-up">
            <div className="form-group">
              <label className="form-label">Prop Firm</label>
              <select className="form-input" value={firm} onChange={e => setFirm(e.target.value)}>
                {FIRM_NAMES.map(f => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
            {firm === 'Other (Custom)' && (
              <div className="form-group">
                <label className="form-label">Firm Name</label>
                <input className="form-input" type="text" placeholder="Enter your prop firm name" value={customFirm} onChange={e => setCustomFirm(e.target.value)} autoFocus/>
              </div>
            )}
            {affiliateUrl && (
              <div style={{ background:'#EEF0FF', border:'1.5px solid #C4BFFF', borderRadius:10, padding:'9px 12px', marginBottom:14, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                <span style={{ fontSize:11, color:'#5B4FE9', fontWeight:600 }}>🔗 Don't have {firm} yet?</span>
                <a href={affiliateUrl} target="_blank" rel="noopener noreferrer" style={{ fontSize:11, fontWeight:700, color:'#5B4FE9', textDecoration:'none', background:'#fff', border:'1.5px solid #C4BFFF', borderRadius:7, padding:'4px 10px' }}>Sign Up →</a>
              </div>
            )}
            <div className="form-group">
              <label className="form-label">Account Size</label>
              <div className="size-grid">
                {SIZES.map(s => (
                  <button key={s.label} className={`sz-btn${(s.value==='custom'?isCustomSz:(sizeVal===s.value&&!isCustomSz))?' active':''}`} onClick={() => handleSizeClick(s)}>{s.label}</button>
                ))}
              </div>
              {isCustomSz && <input className="form-input" type="number" placeholder="Enter amount e.g. 15000" value={customSz} onChange={e => setCustomSz(e.target.value)} style={{ marginTop:10 }}/>}
            </div>
            <div className="form-row">
              <div className="form-group" style={{ marginBottom:0 }}>
                <label className="form-label">Status</label>
                <select className="form-input" value={status} onChange={e => setStatus(e.target.value)}>
                  {STATUSES.map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
              <div className="form-group" style={{ marginBottom:0 }}>
                <label className="form-label">Fee Paid ($)</label>
                <input className="form-input" type="number" placeholder="0" value={investment} onChange={e => setInvestment(e.target.value)}/>
              </div>
            </div>
            <div className="form-group" style={{ marginTop:14 }}>
              <label className="form-label">Notes (optional)</label>
              <textarea className="form-input" rows={2} style={{ resize:'none' }} placeholder="Any notes about this account..." value={notes} onChange={e => setNotes(e.target.value)}/>
            </div>
            <div style={{ display:'flex', gap:10, marginTop:8, paddingBottom:32 }}>
              <button className="btn btn-ghost" onClick={() => nav(-1)}>Cancel</button>
              <button className="btn btn-primary" onClick={() => {
                const err = validateStep1()
                if (err) return showToast(err, 'error')
                setStep(2)
              }}>Next: Add Rules →</button>
            </div>
          </div>
        )}

        {/* ── STEP 2 — RULES ── */}
        {step === 2 && (
          <div className="fade-up">
            <div style={{ background:'#EEF0FF', border:'1.5px solid #C4BFFF', borderRadius:12, padding:'11px 13px', marginBottom:14, display:'flex', gap:9 }}>
              <span style={{ fontSize:16 }}>💡</span>
              <p style={{ fontSize:11, color:'#4338CA', fontWeight:600, lineHeight:1.5 }}>
                Log the specific rules for <strong>{firmName} {sizeLabel}</strong>. You fill in the values — because every firm is different. Leave any rule blank to skip it.
              </p>
            </div>
            {rules.map((r, i) => (
              <div key={i} style={{ background:'#fff', border:'1.5px solid #E2E8F8', borderRadius:12, padding:'11px 13px', marginBottom:9, boxShadow:'0 2px 6px rgba(0,0,0,0.04)' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:7 }}>
                  <span style={{ fontSize:12, fontWeight:800, color:'#0F172A' }}>{r.icon} {r.name}</span>
                  <label style={{ display:'flex', alignItems:'center', gap:5, cursor:'pointer' }}>
                    <input type="checkbox" checked={r.enabled} onChange={() => toggleRule(i)} style={{ accentColor:'#5B4FE9', width:14, height:14 }}/>
                    <span style={{ fontSize:10, color:'#94A3B8', fontWeight:600 }}>Track</span>
                  </label>
                </div>
                {r.enabled && (
                  <input className="form-input" type="text" placeholder={r.placeholder} value={r.value} onChange={e => updateRule(i, e.target.value)} style={{ fontSize:13 }}/>
                )}
              </div>
            ))}
            {/* Custom rules */}
            {customRules.map((r,i) => (
              <div key={i} style={{ background:'#fff', border:'1.5px solid #E2E8F8', borderRadius:12, padding:'11px 13px', marginBottom:9, boxShadow:'0 2px 6px rgba(0,0,0,0.04)' }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:7 }}>
                  <span style={{ fontSize:12, fontWeight:800, color:'#0F172A' }}>📌 Custom Rule</span>
                  <button onClick={() => removeCustom(i)} style={{ background:'#FEF2F2', border:'1.5px solid #FCA5A5', borderRadius:7, color:'#DC2626', fontSize:10, fontWeight:700, padding:'3px 8px', cursor:'pointer' }}>Remove</button>
                </div>
                <input className="form-input" type="text" placeholder="Rule name e.g. Copy Trading" value={r.name} onChange={e => updateCustom(i,'name',e.target.value)} style={{ marginBottom:8 }}/>
                <input className="form-input" type="text" placeholder="Rule detail e.g. Not allowed" value={r.value} onChange={e => updateCustom(i,'value',e.target.value)}/>
              </div>
            ))}
            <button onClick={addCustomRule} style={{ width:'100%', background:'none', border:'2px dashed #C4BFFF', borderRadius:12, padding:'11px', color:'#5B4FE9', fontFamily:"var(--font)", fontSize:13, fontWeight:700, cursor:'pointer', marginBottom:14, display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
              <span style={{ fontSize:18 }}>+</span> Add Custom Rule
            </button>
            <div style={{ display:'flex', gap:10, paddingBottom:32 }}>
              <button className="btn btn-ghost" onClick={() => setStep(1)}>← Back</button>
              <button className="btn btn-primary" onClick={() => setStep(3)}>Next: Review →</button>
            </div>
          </div>
        )}

        {/* ── STEP 3 — REVIEW ── */}
        {step === 3 && (
          <div className="fade-up">
            <div style={{ background:'#fff', border:`2px solid ${m.border}`, borderTop:`4px solid ${m.color}`, borderRadius:18, padding:16, marginBottom:14 }}>
              <div style={{ display:'flex', alignItems:'center', gap:12, marginBottom:12 }}>
                <div style={{ width:44, height:44, borderRadius:13, background:m.bg, display:'flex', alignItems:'center', justifyContent:'center', fontSize:18, fontWeight:900, fontFamily:"'Syne',sans-serif", color:m.color, flexShrink:0 }}>{firmName.charAt(0)}</div>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:15, fontWeight:800, color:'#0F172A' }}>{firmName}</div>
                  <div style={{ fontSize:11, color:'#475569', marginTop:2 }}>{sizeLabel} · {status}</div>
                </div>
                <span className={`badge badge-${status.toLowerCase()}`}>{m.emoji} {status}</span>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
                <div style={{ background:'#F7F9FF', borderRadius:9, padding:9 }}>
                  <div style={{ fontSize:8, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:0.8, marginBottom:3 }}>Fee Paid</div>
                  <div style={{ fontSize:15, fontWeight:900, color:'#0F172A' }}>${investment||0}</div>
                </div>
                <div style={{ background:'#F7F9FF', borderRadius:9, padding:9 }}>
                  <div style={{ fontSize:8, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:0.8, marginBottom:3 }}>Rules Logged</div>
                  <div style={{ fontSize:15, fontWeight:900, color:'#5B4FE9' }}>
                    {rules.filter(r=>r.enabled&&r.value.trim()).length + customRules.filter(r=>r.name.trim()&&r.value.trim()).length}
                  </div>
                </div>
              </div>
            </div>
            {/* Rules summary */}
            <div style={{ fontSize:10, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:1, marginBottom:8 }}>Rules to be saved</div>
            {[...rules.filter(r=>r.enabled&&r.value.trim()), ...customRules.filter(r=>r.name.trim()&&r.value.trim())].map((r,i) => (
              <div key={i} style={{ background:'#fff', border:'1.5px solid #E2E8F8', borderRadius:10, padding:'9px 12px', display:'flex', alignItems:'center', gap:8, marginBottom:7, boxShadow:'0 1px 4px rgba(0,0,0,0.04)' }}>
                <span style={{ fontSize:13 }}>{r.icon||'📌'}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontSize:10, fontWeight:700, color:'#0F172A' }}>{r.name}</div>
                  <div style={{ fontSize:9, color:'#94A3B8' }}>{r.value}</div>
                </div>
                <span style={{ fontSize:12, fontWeight:800, color:'#059669' }}>✓</span>
              </div>
            ))}
            {rules.filter(r=>r.enabled&&r.value.trim()).length + customRules.filter(r=>r.name.trim()&&r.value.trim()).length === 0 && (
              <div style={{ background:'#FFFBEB', border:'1.5px solid #FCD34D', borderRadius:10, padding:'10px 12px', marginBottom:14, fontSize:11, color:'#D97706', fontWeight:600 }}>
                ⚠ No rules added — you can add them later by editing this account
              </div>
            )}
            <div style={{ background:'#ECFDF5', border:'1.5px solid #6EE7B7', borderRadius:12, padding:12, textAlign:'center', fontSize:12, fontWeight:700, color:'#059669', marginBottom:16, marginTop:8 }}>
              ✓ Ready to save — account will appear on your dashboard
            </div>
            <div style={{ display:'flex', gap:10, paddingBottom:32 }}>
              <button className="btn btn-ghost" onClick={() => setStep(2)}>← Back</button>
              <button className="btn btn-green" onClick={handleSave} disabled={saving}>
                {saving ? <div className="spinner"/> : '✅ Save Account'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
