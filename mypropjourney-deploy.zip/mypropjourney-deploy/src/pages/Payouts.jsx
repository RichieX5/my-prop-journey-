// ══ PAYOUTS ════════════════════════════════════════════════════
import { useApp } from '../context/AppContext'
import { useNavigate } from 'react-router-dom'
import { getGrade } from '../lib/constants'
import { upsertGoal, createMilestone, deleteMilestone } from '../lib/supabase'
import { useState } from 'react'

const fmt  = v => { if(!v&&v!==0)return'$0'; const n=Number(v); if(n>=1e6)return`$${(n/1e6).toFixed(2)}M`; if(n>=1e3)return`$${(n/1e3).toFixed(1)}K`; return`$${n.toLocaleString()}` }
const fmtD = d => { if(!d)return'—'; const p=d.split('-'); const mo=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']; return`${mo[parseInt(p[1])-1]} ${p[2]}, ${p[0]}` }

export function Payouts() {
  const { stats, accounts } = useApp()
  const { allPayouts, totalPay, mainGoal } = stats
  const largest = allPayouts.length ? Math.max(...allPayouts.map(p=>p.amount)) : 0
  const avg      = allPayouts.length ? totalPay / allPayouts.length : 0
  const nav      = useNavigate()

  return (
    <div className="page">
      <div className="page-hdr">
        <div><h1>Payouts</h1><div className="sub">{allPayouts.length} entries</div></div>
        <div style={{ background:'#ECFDF5', border:'1.5px solid #6EE7B7', borderRadius:9, padding:'5px 10px', fontSize:10, fontWeight:700, color:'#059669' }}>+{fmt(totalPay)}</div>
      </div>
      {/* Summary */}
      <div style={{ display:'flex', gap:9, padding:'10px 16px', overflowX:'auto', scrollbarWidth:'none' }}>
        {[
          { l:'Total Earned', v:fmt(totalPay),  c:'#059669' },
          { l:'Largest',      v:fmt(largest),   c:'#0F172A' },
          { l:'Average',      v:fmt(avg),        c:'#0F172A' },
          { l:'Remaining',    v:fmt(Math.max((mainGoal?.target||150000)-totalPay,0)), c:'#5B4FE9' },
        ].map(s=>(
          <div key={s.l} style={{ flexShrink:0, background:'#fff', border:'1.5px solid #E2E8F8', borderRadius:12, padding:'10px 14px', minWidth:88, boxShadow:'0 2px 6px rgba(0,0,0,0.04)' }}>
            <div style={{ fontSize:8, fontWeight:700, color:'#94A3B8', textTransform:'uppercase', letterSpacing:1, marginBottom:3 }}>{s.l}</div>
            <div style={{ fontSize:16, fontWeight:900, color:s.c }}>{s.v}</div>
          </div>
        ))}
      </div>
      <div style={{ padding:'6px 16px 7px', fontSize:9, fontWeight:700, color:'#94A3B8', letterSpacing:1.5, textTransform:'uppercase' }}>All Entries · Newest First</div>
      {allPayouts.length === 0 ? (
        <div className="empty-state">
          <div className="empty-icon">💰</div>
          <h3>No payouts yet</h3>
          <p>Go to Accounts and tap + Add Payout on any funded account</p>
          <button className="btn btn-primary" style={{width:'auto',padding:'12px 28px'}} onClick={()=>nav('/accounts')}>Go to Accounts</button>
        </div>
      ) : allPayouts.map(p=>(
        <div key={p.id} style={{ margin:'0 16px 9px', background:'#fff', border:'1.5px solid #E2E8F8', borderLeft:'4px solid #059669', borderRadius:14, padding:'12px 13px', display:'flex', alignItems:'center', gap:11, boxShadow:'0 2px 8px rgba(0,0,0,0.05)' }}>
          <div style={{ width:36, height:36, borderRadius:11, background:'#ECFDF5', display:'flex', alignItems:'center', justifyContent:'center', fontSize:15, flexShrink:0 }}>💚</div>
          <div style={{ flex:1, minWidth:0 }}>
            <div style={{ fontSize:12, fontWeight:800, color:'#0F172A' }}>{p.firm}</div>
            <div style={{ fontSize:10, color:'#94A3B8', marginTop:1 }}>{fmtD(p.date)}{p.note?` · ${p.note}`:''}</div>
          </div>
          <div style={{ fontSize:16, fontWeight:900, color:'#059669', flexShrink:0 }}>+${Number(p.amount).toLocaleString()}</div>
        </div>
      ))}
    </div>
  )
}

// ══ PERFORMANCE ════════════════════════════════════════════════
export function Performance() {
  const { stats } = useApp()
  const { perf } = stats

  if (!perf) return (
    <div className="page">
      <div className="page-hdr"><div><h1>Performance</h1><div className="sub">Trading assessment</div></div></div>
      <div className="empty-state">
        <div className="empty-icon">📈</div>
        <h3>Add accounts to unlock</h3>
        <p>Your performance will be scored across 5 dimensions once you have account data.</p>
      </div>
    </div>
  )

  const bars = [
    { label:'Win Rate',            score:perf.winScore,    color:'#5B4FE9', detail:`${Math.round(perf.winRate*100)}% accounts reach funded` },
    { label:'Return on Investment', score:perf.roiScore,   color:'#059669', detail:perf.roi>=0?`${Math.round(perf.roi*100)}% return on fees`:'Payouts below fees — keep pushing' },
    { label:'Risk Control',        score:perf.breachScore, color:'#D97706', detail:`${Math.round(perf.breachRate*100)}% breach rate` },
    { label:'Diversification',     score:perf.divScore,    color:'#0284C7', detail:`Active across multiple firms` },
    { label:'Goal Progress',       score:perf.payScore,    color:'#7C3AED', detail:`${perf.payScore}% toward target` },
  ]

  const insights = [
    perf.breachScore<60 && { type:'warn', icon:'⚠️', text:'High breach rate — reduce risk exposure per account.' },
    perf.roiScore<30    && { type:'warn', icon:'📉', text:'ROI is low. Focus on passing challenges before scaling.' },
    perf.winScore>=75   && { type:'good', icon:'🏆', text:'Excellent funding rate — you\'re passing consistently!' },
    perf.divScore>=60   && { type:'info', icon:'🔀', text:'Good diversification across multiple firms.' },
    perf.payScore>=50   && { type:'good', icon:'💰', text:'Halfway to your goal — keep the momentum going!' },
    perf.overall>=80    && { type:'good', icon:'🚀', text:'Exceptional performance. Scale with discipline.' },
  ].filter(Boolean)

  return (
    <div className="page">
      <div className="page-hdr"><div><h1>Performance</h1><div className="sub">Scored across 5 dimensions</div></div></div>
      {/* Grade card */}
      <div style={{ margin:'12px 16px 0', background:'linear-gradient(145deg,#5B4FE9,#4338CA)', borderRadius:22, padding:20, display:'flex', alignItems:'center', gap:18, boxShadow:'0 8px 28px rgba(91,79,233,0.35)' }}>
        <div style={{ width:80, height:80, borderRadius:'50%', background:'rgba(255,255,255,0.15)', border:'2px solid rgba(255,255,255,0.3)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', flexShrink:0 }}>
          <div style={{ fontFamily:"'Syne',sans-serif", fontSize:36, fontWeight:900, color:'#fff', lineHeight:1 }}>{perf.grade}</div>
          <div style={{ fontSize:10, color:'rgba(255,255,255,0.7)', fontWeight:700 }}>{perf.overall}/100</div>
        </div>
        <div>
          <div style={{ fontSize:9, color:'rgba(255,255,255,0.65)', fontWeight:700, textTransform:'uppercase', letterSpacing:1, marginBottom:3 }}>Overall Grade</div>
          <div style={{ fontFamily:"'Syne',sans-serif", fontSize:20, fontWeight:900, color:'#fff', marginBottom:4 }}>{perf.label}</div>
          <div style={{ fontSize:10, color:'rgba(255,255,255,0.75)', lineHeight:1.5 }}>
            {perf.grade==='S'?'You are operating at elite level. Outstanding.':perf.grade==='A'?'Strong across the board. Keep pushing forward.':perf.grade==='B'?'Good progress — room to grow in a few areas.':'Building your track record. Stay consistent.'}
          </div>
        </div>
      </div>
      <div style={{ padding:'13px 16px 8px', fontSize:12, fontWeight:800, color:'#0F172A' }}>Score Breakdown</div>
      {bars.map(b=>(
        <div key={b.label} style={{ padding:'0 16px', marginBottom:12 }}>
          <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
            <span style={{ fontSize:12, fontWeight:700, color:'#0F172A' }}>{b.label}</span>
            <span style={{ fontSize:12, fontWeight:900, color:b.color }}>{b.score}pts</span>
          </div>
          <div style={{ height:8, background:'#E2E8F8', borderRadius:4, overflow:'hidden' }}>
            <div style={{ height:'100%', width:`${b.score}%`, background:b.color, borderRadius:4, transition:'width .8s ease' }}/>
          </div>
          <div style={{ fontSize:9, color:'#94A3B8', marginTop:3 }}>{b.detail}</div>
        </div>
      ))}
      {insights.length > 0 && (
        <>
          <div style={{ padding:'10px 16px 7px', fontSize:12, fontWeight:800, color:'#0F172A' }}>Insights</div>
          <div style={{ padding:'0 16px' }}>
            {insights.map((ins,i)=>(
              <div key={i} className={`insight ins-${ins.type}`}>
                <span style={{ fontSize:16 }}>{ins.icon}</span>
                <p>{ins.text}</p>
              </div>
            ))}
          </div>
        </>
      )}
      <div style={{ height:16 }}/>
    </div>
  )
}

// ══ GOALS ══════════════════════════════════════════════════════
export function Goals() {
  const { goals, milestones, userId, stats, showToast, refresh } = useApp()
  const { totalPay, goalPct } = stats
  const mainGoal = goals.find(g=>g.is_main) || { target:150000 }
  const [editGoal, setEditGoal]   = useState(false)
  const [newTarget, setNewTarget] = useState(mainGoal.target||150000)
  const [addMS, setAddMS]         = useState(false)
  const [msLabel,  setMsLabel]    = useState('')
  const [msTarget, setMsTarget]   = useState('')
  const [msCurrent,setMsCurrent]  = useState('')
  const [msUnit,   setMsUnit]     = useState('$')
  const [saving,   setSaving]     = useState(false)

  async function saveGoal() {
    setSaving(true)
    const { error } = await upsertGoal({ ...mainGoal, user_id:userId, target:parseFloat(newTarget)||150000, is_main:true })
    setSaving(false)
    if (error) showToast(error.message,'error')
    else { showToast('Goal updated ✓','success'); refresh(); setEditGoal(false) }
  }

  async function saveMS() {
    if (!msLabel.trim()) return showToast('Enter a milestone name','error')
    setSaving(true)
    const { error } = await createMilestone({ user_id:userId, label:msLabel.trim(), target_value:parseFloat(msTarget)||0, current_value:parseFloat(msCurrent)||0, unit:msUnit })
    setSaving(false)
    if (error) showToast(error.message,'error')
    else { showToast('Milestone added ✓','success'); refresh(); setAddMS(false); setMsLabel(''); setMsTarget(''); setMsCurrent(''); }
  }

  async function delMS(id) {
    if (!confirm('Delete this milestone?')) return
    const { error } = await deleteMilestone(id)
    if (error) showToast(error.message,'error')
    else { showToast('Removed','success'); refresh() }
  }

  const MONTH_COLORS = ['#5B4FE9','#059669','#D97706','#0284C7','#DC2626']

  return (
    <div className="page">
      <div className="page-hdr">
        <div><h1>Goals</h1><div className="sub">Your trading targets</div></div>
        <button className="add-btn" onClick={()=>setAddMS(true)}>+ Milestone</button>
      </div>

      {/* Main goal */}
      <div style={{ margin:'12px 16px 0', background:'linear-gradient(145deg,#5B4FE9,#4338CA)', borderRadius:22, padding:20, boxShadow:'0 8px 28px rgba(91,79,233,0.35)' }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:12 }}>
          <div>
            <div style={{ fontSize:9, color:'rgba(255,255,255,0.65)', fontWeight:700, textTransform:'uppercase', letterSpacing:1, marginBottom:4 }}>🎯 Main Payout Goal</div>
            <div style={{ fontFamily:"'Syne',sans-serif", fontSize:28, fontWeight:900, color:'#fff' }}>{fmt(mainGoal.target||150000)}</div>
            <div style={{ fontSize:11, fontWeight:700, color:'#A5F3D4', marginTop:3 }}>{fmt(totalPay)} earned · {Math.round(goalPct)}% complete</div>
          </div>
          <button onClick={()=>setEditGoal(true)} style={{ background:'rgba(255,255,255,0.18)', border:'1px solid rgba(255,255,255,0.3)', borderRadius:8, color:'#fff', fontFamily:'var(--font)', fontSize:10, fontWeight:700, padding:'6px 10px', cursor:'pointer' }}>Edit</button>
        </div>
        <div style={{ height:10, background:'rgba(255,255,255,0.18)', borderRadius:5, overflow:'hidden', marginBottom:6 }}>
          <div style={{ height:'100%', width:`${goalPct}%`, background:'linear-gradient(90deg,#A5F3D4,#6EE7B7)', borderRadius:5, transition:'width .8s ease' }}/>
        </div>
        <div style={{ display:'flex', justifyContent:'space-between' }}>
          {['$0', fmt((mainGoal.target||150000)*0.25), fmt((mainGoal.target||150000)*0.5), fmt((mainGoal.target||150000)*0.75), fmt(mainGoal.target||150000)].map(l=>(
            <span key={l} style={{ fontSize:8, color:'rgba(255,255,255,0.45)' }}>{l}</span>
          ))}
        </div>
        <div style={{ background:'rgba(255,255,255,0.12)', border:'1px solid rgba(255,255,255,0.2)', borderRadius:10, padding:10, fontSize:11, color:'#fff', fontWeight:700, marginTop:11, textAlign:'center' }}>
          {goalPct >= 100 ? '🎉 Goal reached! Time to set a new one.' : goalPct >= 75 ? `🔥 Almost there! ${fmt(Math.max((mainGoal.target||150000)-totalPay,0))} to go` : goalPct >= 50 ? `🚀 Over halfway! ${fmt(Math.max((mainGoal.target||150000)-totalPay,0))} remaining` : `💪 Keep going! ${fmt(Math.max((mainGoal.target||150000)-totalPay,0))} remaining`}
        </div>
      </div>

      <div style={{ padding:'14px 16px 8px', fontSize:12, fontWeight:800, color:'#0F172A' }}>Milestones</div>

      {milestones.length === 0 && (
        <div style={{ margin:'0 16px', background:'#fff', border:'2px dashed #C4BFFF', borderRadius:16, padding:'20px', textAlign:'center' }}>
          <div style={{ fontSize:28, marginBottom:8 }}>🎯</div>
          <div style={{ fontSize:13, fontWeight:700, color:'#475569', marginBottom:4 }}>No milestones yet</div>
          <div style={{ fontSize:11, color:'#94A3B8' }}>Tap + Milestone to add goals like monthly payouts or funded account targets</div>
        </div>
      )}

      {milestones.map((ms,i)=>{
        const pct = ms.target_value > 0 ? Math.min((ms.current_value/ms.target_value)*100,100) : 0
        const color = MONTH_COLORS[i%MONTH_COLORS.length]
        return (
          <div key={ms.id} style={{ margin:'0 16px 9px', background:'#fff', border:'1.5px solid #E2E8F8', borderRadius:14, padding:'13px 14px', boxShadow:'0 2px 8px rgba(0,0,0,0.05)' }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 }}>
              <span style={{ fontSize:13, fontWeight:800, color:'#0F172A' }}>{ms.label}</span>
              <div style={{ display:'flex', alignItems:'center', gap:8 }}>
                <span style={{ fontSize:12, fontWeight:800, color }}>{ms.unit}{Number(ms.current_value||0).toLocaleString()} / {ms.unit}{Number(ms.target_value||0).toLocaleString()}</span>
                <button onClick={()=>delMS(ms.id)} style={{ background:'none', border:'none', color:'#FCA5A5', fontSize:14, cursor:'pointer', padding:2 }}>✕</button>
              </div>
            </div>
            <div style={{ height:7, background:'#E2E8F8', borderRadius:4, overflow:'hidden' }}>
              <div style={{ height:'100%', width:`${pct}%`, background:color, borderRadius:4, transition:'width .8s ease' }}/>
            </div>
            <div style={{ fontSize:10, color:'#94A3B8', marginTop:4 }}>{Math.round(pct)}% complete</div>
          </div>
        )
      })}
      <div style={{ height:16 }}/>

      {/* Edit goal modal */}
      {editGoal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setEditGoal(false)}>
          <div className="modal-box">
            <div className="modal-handle"/>
            <div className="modal-hdr"><span className="modal-title">Edit Main Goal</span><button className="modal-close" onClick={()=>setEditGoal(false)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Target Total Payout ($)</label>
                <input className="form-input" type="number" value={newTarget} onChange={e=>setNewTarget(e.target.value)}/>
                <div style={{ fontSize:11, color:'#94A3B8', marginTop:5 }}>Default: $150,000 across all firms</div>
              </div>
              <div style={{ display:'flex', gap:10, marginTop:8 }}>
                <button className="btn btn-ghost" onClick={()=>setEditGoal(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={saveGoal} disabled={saving}>{saving?<div className="spinner"/>:'Save Goal'}</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add milestone modal */}
      {addMS && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setAddMS(false)}>
          <div className="modal-box">
            <div className="modal-handle"/>
            <div className="modal-hdr"><span className="modal-title">Add Milestone</span><button className="modal-close" onClick={()=>setAddMS(false)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Milestone Name</label>
                <input className="form-input" type="text" placeholder="e.g. Monthly Payout Target" value={msLabel} onChange={e=>setMsLabel(e.target.value)} autoFocus/>
              </div>
              <div className="form-row">
                <div className="form-group" style={{marginBottom:0}}>
                  <label className="form-label">Unit</label>
                  <select className="form-input" value={msUnit} onChange={e=>setMsUnit(e.target.value)}>
                    <option value="$">$ (Dollar)</option>
                    <option value="">Count (accounts, firms)</option>
                    <option value="%">% (Percentage)</option>
                  </select>
                </div>
                <div className="form-group" style={{marginBottom:0}}>
                  <label className="form-label">Target</label>
                  <input className="form-input" type="number" placeholder="e.g. 20000" value={msTarget} onChange={e=>setMsTarget(e.target.value)}/>
                </div>
              </div>
              <div className="form-group" style={{marginTop:12}}>
                <label className="form-label">Current Progress</label>
                <input className="form-input" type="number" placeholder="e.g. 14000" value={msCurrent} onChange={e=>setMsCurrent(e.target.value)}/>
              </div>
              <div style={{ display:'flex', gap:10, marginTop:8 }}>
                <button className="btn btn-ghost" onClick={()=>setAddMS(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={saveMS} disabled={saving}>{saving?<div className="spinner"/>:'Add Milestone'}</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Payouts
