// ── ONBOARDING ────────────────────────────────────
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

const SLIDES = [
  { emoji:'📊', color:'#5B4FE9', title:'All Your Accounts.\nOne Dashboard.', desc:'See every prop firm account — funded, in challenge, breached — all in one place. No more switching between platforms.' },
  { emoji:'⚖️', color:'#059669', title:'Log Rules Per Account', desc:'When you add a Funding Pips account, you log their specific rules. When you add GOAT Funded, you log GOAT\'s rules. Each account carries its own ruleset.' },
  { emoji:'🎯', color:'#D97706', title:'Track Your Goal', desc:'Set your $150K target. Every payout from every firm counts toward one combined goal. Watch it grow in real time.' },
]

export function Onboarding() {
  const [i, setI] = useState(0)
  const nav = useNavigate()
  const s = SLIDES[i]
  return (
    <div style={{ height:'100vh', overflow:'auto', background:'#F0F4FF', display:'flex', flexDirection:'column', padding:'0 24px' }}>
      <div style={{ display:'flex', justifyContent:'flex-end', padding:'52px 0 0' }}>
        <button onClick={() => nav('/register')} style={{ background:'none', border:'none', color:'#94A3B8', fontSize:13, fontWeight:700, cursor:'pointer' }}>Skip</button>
      </div>
      <div style={{ flex:1, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center' }}>
        <div key={i} className="fade-up" style={{ textAlign:'center' }}>
          <div style={{ width:96, height:96, borderRadius:28, background:`${s.color}18`, border:`1.5px solid ${s.color}44`, display:'flex', alignItems:'center', justifyContent:'center', fontSize:44, margin:'0 auto 24px' }}>{s.emoji}</div>
          <h1 style={{ fontFamily:"'Syne',sans-serif", fontSize:26, fontWeight:900, color:'#0F172A', marginBottom:14, whiteSpace:'pre-line', lineHeight:1.15 }}>{s.title}</h1>
          <p style={{ fontSize:14, color:'#475569', lineHeight:1.7, maxWidth:300, margin:'0 auto' }}>{s.desc}</p>
        </div>
      </div>
      <div style={{ display:'flex', justifyContent:'center', gap:8, marginBottom:22 }}>
        {SLIDES.map((_,j) => <div key={j} onClick={() => setI(j)} style={{ width:j===i?24:8, height:8, borderRadius:4, background:j===i?s.color:'#C8D4F0', cursor:'pointer', transition:'all .3s' }} />)}
      </div>
      <div style={{ paddingBottom:'calc(env(safe-area-inset-bottom,0px) + 28px)', display:'flex', flexDirection:'column', gap:10 }}>
        <button className="btn btn-primary" onClick={() => i < SLIDES.length-1 ? setI(i+1) : nav('/register')}>
          {i < SLIDES.length-1 ? 'Next →' : 'Get Started'}
        </button>
        {i === 0 && <button className="btn btn-ghost" onClick={() => nav('/login')}>Already have an account? Log in</button>}
      </div>
    </div>
  )
}
export default Onboarding
